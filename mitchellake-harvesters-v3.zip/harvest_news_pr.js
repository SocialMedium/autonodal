#!/usr/bin/env node
/**
 * MitchelLake Signal Intelligence — News & PR Harvester v3
 * 
 * Matched to actual MLX PostgreSQL schema:
 *   rss_sources     → UUID id, source_type, consecutive_errors, signal_types[]
 *   external_documents → UUID id, source_url, source_url_hash, source_type, extracted_signals jsonb
 *   signal_events   → UUID id, signal_type ENUM, confidence_score, evidence_summary, evidence_snippet
 * 
 * Usage:
 *   node scripts/harvest_news_pr.js --seed           # Seed 13 PR/news sources
 *   node scripts/harvest_news_pr.js                  # Harvest all enabled sources
 *   node scripts/harvest_news_pr.js --source gnw     # Harvest matching sources
 *   node scripts/harvest_news_pr.js --stats          # Show statistics
 */

require('dotenv').config();
const { Pool } = require('pg');
const crypto = require('crypto');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

const DELAY_MS = 2000;
const USER_AGENT = 'MitchelLakeSignals/1.0 (Executive Search Intelligence)';

// ══════════════════════════════════════════════════════════════
// SIGNAL DETECTION PATTERNS → mapped to signal_type ENUM
// ══════════════════════════════════════════════════════════════
// 
// Valid signal_type ENUM values:
//   capital_raising, geographic_expansion, strategic_hiring,
//   ma_activity, partnership, product_launch,
//   leadership_change, layoffs, restructuring
//

const SIGNAL_PATTERNS = {
  capital_raising:       /\b(series [A-Z]|seed round|raise[ds]?\s+\$|funding round|venture capital|secured \$|raised \$|funding of \$|pre-IPO|growth equity|private placement|IPO|initial public offering|SPAC|direct listing|files? (?:for|to) (?:go )?public)\b/i,
  geographic_expansion:  /\b(expands? (?:to|into|in)|opens? (?:new|office|headquarters)|enters? (?:the|new)|new (?:office|headquarters|hub|center)|relocat|establishes? (?:presence|operations))\b/i,
  strategic_hiring:      /\b(appoints?|names?|hires?|recruits?|brings? on)\s+(?:new\s+)?(?:chief|CEO|CTO|CFO|COO|CRO|CPO|CISO|CMO|VP|SVP|EVP|president|director|head of|managing director|partner|general manager|country manager)\b/i,
  ma_activity:           /\b(acquir|merger|acquisition|takeover|buyout|divest|spin.?off|carve.?out|definitive agreement|combines? with|strategic review|private equity|PE (?:firm|fund|backed)|leveraged buyout|LBO|management buyout|MBO|bought by)\b/i,
  partnership:           /\b(partner(?:ship|ed|ing)|collaborat(?:ion|e|ing)|joint venture|strategic alliance|teaming agreement)\b/i,
  product_launch:        /\b(launch(?:es|ed|ing)?|unveil(?:s|ed)?|introduce[ds]?|announce[ds]?.*(?:product|platform|solution)|generally available)\b/i,
  leadership_change:     /\b(step(?:s|ped)? down|resign(?:s|ed)?|depart(?:s|ed|ure)|leaves?|left|exit(?:s|ed)?)\s+(?:as\s+)?(?:chief|CEO|CTO|CFO|COO|president|chairman)\b/i,
  layoffs:               /\b(layoff|laid off|cut.*(?:jobs|staff|workforce)|workforce reduction|redundanc)\b/i,
  restructuring:         /\b(restructur|reorganiz|downsiz|transform(?:ation|ing)|turnaround|operational review|cost.?cutting)\b/i,
};

// Theme detection for extracted_signals jsonb
const THEME_PATTERNS = {
  technology:     /\b(technology|software|SaaS|cloud|AI|artificial intelligence|machine learning|digital transformation|platform)\b/i,
  fintech:        /\b(fintech|financial technology|payment|neobank|blockchain|DeFi|digital banking|insurtech|regtech|lending)\b/i,
  healthcare:     /\b(healthcare|health ?tech|medical|clinical|telemedicine|diagnostics|pharma|biotech|life science)\b/i,
  cybersecurity:  /\b(cybersecurity|cyber security|infosec|zero trust|threat detection|endpoint security)\b/i,
  cleantech:      /\b(clean ?tech|renewable|solar|wind|hydrogen|carbon|EV|electric vehicle|battery|sustainability|climate)\b/i,
  ecommerce:      /\b(e.?commerce|marketplace|retail tech|D2C|direct.?to.?consumer)\b/i,
  proptech:       /\b(prop ?tech|real estate tech|construction tech|smart building)\b/i,
  gaming:         /\b(gaming|game studio|esports|metaverse)\b/i,
  media:          /\b(media|content|streaming|creator economy|digital media|publishing)\b/i,
  logistics:      /\b(supply chain|logistics|freight|warehouse|last.?mile|shipping)\b/i,
  semiconductor:  /\b(semiconductor|chip|wafer|fab|GPU|processor)\b/i,
};

// MitchelLake geography relevance
const GEO_PATTERNS = {
  australia:       /\b(Australia|Sydney|Melbourne|Brisbane|Perth|Adelaide|Canberra|ASX)\b/i,
  new_zealand:     /\b(New Zealand|Auckland|Wellington|NZX)\b/i,
  singapore:       /\b(Singapore|SGX|Temasek|GIC)\b/i,
  southeast_asia:  /\b(Southeast Asia|SEA|Indonesia|Thailand|Vietnam|Philippines|Malaysia|Jakarta|Bangkok)\b/i,
  uk:              /\b(United Kingdom|UK|London|LSE|Manchester|Edinburgh|FTSE)\b/i,
  us:              /\b(United States|US|USA|Silicon Valley|San Francisco|New York|NYSE|NASDAQ)\b/i,
  europe:          /\b(Europe|EU|Germany|France|Netherlands|Berlin|Amsterdam|Paris|Stockholm)\b/i,
};

// ══════════════════════════════════════════════════════════════
// NEWS/PR RSS SOURCES
// ══════════════════════════════════════════════════════════════

const NEWS_SOURCES = [
  { name: 'GlobeNewswire — M&A', source_type: 'news_pr',
    url: 'https://www.globenewswire.com/RssFeed/subjectcode/27-Mergers%20and%20Acquisitions/feedTitle/GlobeNewswire%20-%20Mergers%20and%20Acquisitions',
    signal_types: ['ma_activity', 'capital_raising'] },
  { name: 'GlobeNewswire — Business Contracts', source_type: 'news_pr',
    url: 'https://www.globenewswire.com/RssFeed/subjectcode/7-Business%20Contracts/feedTitle/GlobeNewswire%20-%20Business%20Contracts',
    signal_types: ['partnership', 'product_launch'] },
  { name: 'GlobeNewswire — Public Companies', source_type: 'news_pr',
    url: 'https://www.globenewswire.com/RssFeed/orgclass/1/feedTitle/GlobeNewswire%20-%20News%20about%20Public%20Companies',
    signal_types: ['capital_raising', 'leadership_change', 'restructuring'] },
  { name: 'PR Newswire — Technology', source_type: 'news_pr',
    url: 'https://www.prnewswire.com/rss/technology-latest-news/technology-latest-news-list.rss',
    signal_types: ['strategic_hiring', 'product_launch', 'capital_raising'] },
  { name: 'PR Newswire — Financial Services', source_type: 'news_pr',
    url: 'https://www.prnewswire.com/rss/financial-services-latest-news/financial-services-latest-news-list.rss',
    signal_types: ['capital_raising', 'partnership', 'ma_activity'] },
  { name: 'Business Wire — Technology', source_type: 'news_pr',
    url: 'https://feed.businesswire.com/rss/home/?rss=G1QFDERJXkJeEFpTXA==',
    signal_types: ['product_launch', 'strategic_hiring', 'partnership'] },
  { name: 'TechCrunch', source_type: 'news_pr',
    url: 'https://techcrunch.com/feed/',
    signal_types: ['capital_raising', 'strategic_hiring', 'product_launch'] },
  { name: 'Startup Daily AU', source_type: 'news_pr',
    url: 'https://www.startupdaily.net/feed/',
    signal_types: ['capital_raising', 'strategic_hiring', 'geographic_expansion'] },
  { name: 'SmartCompany AU', source_type: 'news_pr',
    url: 'https://www.smartcompany.com.au/feed/',
    signal_types: ['capital_raising', 'layoffs', 'leadership_change'] },
  { name: 'Tech in Asia', source_type: 'news_pr',
    url: 'https://www.techinasia.com/feed',
    signal_types: ['capital_raising', 'geographic_expansion', 'ma_activity'] },
  { name: 'e27', source_type: 'news_pr',
    url: 'https://e27.co/feed/',
    signal_types: ['capital_raising', 'strategic_hiring'] },
  { name: 'Sifted EU', source_type: 'news_pr',
    url: 'https://sifted.eu/feed',
    signal_types: ['capital_raising', 'geographic_expansion', 'strategic_hiring'] },
  { name: 'UKTN', source_type: 'news_pr',
    url: 'https://www.uktech.news/feed',
    signal_types: ['capital_raising', 'strategic_hiring', 'product_launch'] },
];

// ══════════════════════════════════════════════════════════════
// HELPERS
// ══════════════════════════════════════════════════════════════

const sleep = ms => new Promise(r => setTimeout(r, ms));
function md5(str) { return crypto.createHash('md5').update(str || '').digest('hex'); }

function stripHTML(str) {
  if (!str) return '';
  return str.replace(/<!\[CDATA\[(.*?)\]\]>/gs, '$1').replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#x27;/g, "'").replace(/&[a-z]+;/gi, ' ')
    .replace(/\s+/g, ' ').trim();
}

function detectSignals(text) {
  return Object.entries(SIGNAL_PATTERNS).filter(([, p]) => p.test(text)).map(([s]) => s);
}
function detectThemes(text) {
  return Object.entries(THEME_PATTERNS).filter(([, p]) => p.test(text)).map(([t]) => t);
}
function detectGeographies(text) {
  return Object.entries(GEO_PATTERNS).filter(([, p]) => p.test(text)).map(([g]) => g);
}

function extractCompanyHint(text) {
  const m = text.match(/\b([A-Z][A-Za-z&. ]{2,30}(?:Inc|Corp|Ltd|LLC|Co|SA|AG|PLC|Limited|Group|Holdings|Ventures|Capital|Partners)\.?)\b/)
    || text.match(/\b([A-Z][A-Za-z]{2,20})\s+(?:today announced|announced today|reports|launched|unveiled|appoints?|names?|hires?)/);
  return m ? m[1].trim() : null;
}

function extractAmount(text) {
  const m = text.match(/\$\s*([\d,.]+)\s*(billion|B)\b/i) || text.match(/\$\s*([\d,.]+)\s*(million|M)\b/i);
  if (!m) return null;
  const num = parseFloat(m[1].replace(/,/g, ''));
  return m[2].toLowerCase().startsWith('b') ? num * 1000 : num;
}

function isEnglish(text) {
  if (!text) return true;
  return (text.match(/\b(the|and|of|to|in|for|is|that|with|this|from|has|was|are|will|said)\b/gi) || []).length >= 2;
}

function scoreConfidence(signals, themes, geos) {
  let score = 0.3;
  if (signals.includes('strategic_hiring')) score += 0.3;
  if (signals.includes('capital_raising')) score += 0.2;
  if (signals.includes('geographic_expansion')) score += 0.15;
  if (signals.includes('leadership_change')) score += 0.25;
  if (signals.includes('ma_activity')) score += 0.15;
  if (signals.includes('layoffs')) score += 0.1;
  if (geos.some(g => ['australia', 'new_zealand', 'singapore', 'southeast_asia', 'uk'].includes(g))) score += 0.1;
  return Math.min(score, 1.0);
}

// Hiring implications for signal_events.hiring_implications jsonb
function buildHiringImplications(signals, companyHint, amount) {
  const implications = [];
  if (signals.includes('capital_raising')) implications.push({ type: 'team_build', detail: `${companyHint || 'Company'} raising capital — likely hiring`, urgency: 'medium' });
  if (signals.includes('strategic_hiring')) implications.push({ type: 'backfill_or_new', detail: 'Executive appointment signals active hiring', urgency: 'high' });
  if (signals.includes('geographic_expansion')) implications.push({ type: 'local_leaders', detail: 'Geographic expansion needs local leadership', urgency: 'high' });
  if (signals.includes('leadership_change')) implications.push({ type: 'backfill', detail: 'Leadership departure creates backfill opportunity', urgency: 'high' });
  if (signals.includes('ma_activity')) implications.push({ type: 'integration_leadership', detail: 'M&A activity needs integration/operating leaders', urgency: 'medium' });
  if (signals.includes('restructuring')) implications.push({ type: 'transformation', detail: 'Restructuring creates transformation leadership needs', urgency: 'medium' });
  return implications.length > 0 ? implications : null;
}

// ══════════════════════════════════════════════════════════════
// RSS PARSING (handles RSS 2.0 + Atom)
// ══════════════════════════════════════════════════════════════

async function fetchAndParseRSS(url) {
  const { parseString } = require('xml2js');
  const response = await fetch(url, {
    headers: { 'User-Agent': USER_AGENT, 'Accept': 'application/rss+xml, application/xml, text/xml, */*' },
    signal: AbortSignal.timeout(30000),
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const xml = await response.text();

  return new Promise((resolve, reject) => {
    parseString(xml, { explicitArray: false, trim: true }, (err, result) => {
      if (err) return reject(err);
      // RSS 2.0
      const channel = result?.rss?.channel;
      if (channel) {
        const items = Array.isArray(channel.item) ? channel.item : channel.item ? [channel.item] : [];
        return resolve(items.map(item => ({
          title: stripHTML(typeof item.title === 'object' ? item.title._ || '' : item.title || ''),
          description: stripHTML(typeof item.description === 'object' ? item.description._ || '' : item.description || ''),
          url: typeof item.link === 'object' ? item.link._ || '' : item.link || '',
          guid: item.guid?._ || item.guid || item.link || '',
          pubDate: item.pubDate || item['dc:date'] || null,
          author: item['dc:creator'] || item.author || null,
        })));
      }
      // Atom
      const feed = result?.feed;
      if (feed) {
        const entries = Array.isArray(feed.entry) ? feed.entry : feed.entry ? [feed.entry] : [];
        return resolve(entries.map(e => ({
          title: stripHTML(typeof e.title === 'object' ? e.title._ || '' : e.title || ''),
          description: stripHTML(typeof e.summary === 'object' ? e.summary._ || '' : e.summary || e.content?._ || ''),
          url: e.link?.$?.href || (typeof e.link === 'string' ? e.link : '') || e.id || '',
          guid: e.id || e.link?.$?.href || '',
          pubDate: e.published || e.updated || null,
          author: e.author?.name || null,
        })));
      }
      resolve([]);
    });
  });
}

// ══════════════════════════════════════════════════════════════
// DATABASE OPERATIONS
// ══════════════════════════════════════════════════════════════

async function seedSources() {
  console.log('\n🌱 Seeding news/PR sources into rss_sources...\n');
  let added = 0;
  for (const src of NEWS_SOURCES) {
    try {
      // Schema: id(uuid), name, source_type, url, poll_interval_minutes, enabled,
      //         credibility_score, signal_types[], last_fetched_at, last_error,
      //         consecutive_errors, created_at
      const result = await pool.query(`
        INSERT INTO rss_sources (name, source_type, url, poll_interval_minutes, enabled, credibility_score, signal_types, created_at)
        VALUES ($1, $2, $3, 30, true, 0.7, $4, NOW())
        ON CONFLICT (url) DO NOTHING
        RETURNING id
      `, [src.name, src.source_type, src.url, src.signal_types]);
      if (result.rowCount > 0) { console.log(`  ✅ ${src.name}`); added++; }
      else console.log(`  ⏭️  ${src.name} (exists)`);
    } catch (err) { console.log(`  ❌ ${src.name}: ${err.message}`); }
  }
  console.log(`\n📊 Added ${added} new sources`);
}

async function harvestSource(source) {
  console.log(`\n  📰 ${source.name}`);
  console.log(`     ${source.url.substring(0, 70)}...`);

  let items;
  try { items = await fetchAndParseRSS(source.url); }
  catch (err) {
    console.log(`     ❌ ${err.message}`);
    try {
      await pool.query(
        `UPDATE rss_sources SET consecutive_errors = COALESCE(consecutive_errors, 0) + 1, last_error = $1 WHERE id = $2`,
        [err.message, source.id]
      );
    } catch(e) {}
    return { success: 0, skipped: 0, signals: 0 };
  }
  console.log(`     Found ${items.length} items`);

  let success = 0, skipped = 0, signalsCreated = 0;

  for (const item of items) {
    if (!item.title) { skipped++; continue; }
    const fullText = `${item.title} ${item.description}`;
    if (!isEnglish(fullText)) { skipped++; continue; }

    const sourceUrlHash = md5(item.url || item.guid || item.title);
    const signals = detectSignals(fullText);
    const themes = detectThemes(fullText);
    const geos = detectGeographies(fullText);
    const companyHint = extractCompanyHint(fullText);
    const amount = extractAmount(fullText);
    const confidence = scoreConfidence(signals, themes, geos);

    try {
      // INSERT into external_documents — matched to actual schema:
      //   source_type, source_name, source_url, source_url_hash, title, content, summary,
      //   author, published_at, fetched_at, extracted_entities, extracted_signals,
      //   processing_status, source_id
      const result = await pool.query(`
        INSERT INTO external_documents (
          source_type, source_name, source_url, source_url_hash,
          title, content, summary, author,
          published_at, fetched_at,
          extracted_entities, extracted_signals,
          processing_status, source_id, created_at
        ) VALUES (
          'news_pr', $1, $2, $3,
          $4, $5, $6, $7,
          $8, NOW(),
          $9, $10,
          'processed', $11, NOW()
        )
        ON CONFLICT (source_url_hash) DO NOTHING
        RETURNING id
      `, [
        source.name,                                          // source_name
        (item.url || '').substring(0, 2000),                  // source_url
        sourceUrlHash,                                        // source_url_hash
        item.title.substring(0, 500),                         // title
        item.description.substring(0, 5000),                  // content
        item.description.substring(0, 500),                   // summary (truncated)
        item.author,                                          // author
        item.pubDate ? new Date(item.pubDate).toISOString() : null, // published_at
        JSON.stringify({ companies: companyHint ? [companyHint] : [], geographies: geos }), // extracted_entities
        JSON.stringify({ signals, themes, confidence, amount_millions: amount }),             // extracted_signals
        source.id,                                            // source_id (UUID FK)
      ]);

      if (result.rowCount === 0) { skipped++; continue; }
      success++;
      const docId = result.rows[0].id;

      // Create signal_events for high-value signals
      // signal_type must be one of the ENUM values
      if (signals.length > 0 && confidence >= 0.4) {
        const hiringImpl = buildHiringImplications(signals, companyHint, amount);

        for (const signalType of signals) {
          try {
            await pool.query(`
              INSERT INTO signal_events (
                signal_type, company_name,
                confidence_score, scoring_breakdown,
                evidence_summary, evidence_snippet, evidence_doc_ids,
                source_url, source_document_id,
                detected_at, signal_date, signal_category,
                hiring_implications,
                created_at, updated_at
              ) VALUES (
                $1::signal_type, $2,
                $3, $4,
                $5, $6, $7,
                $8, $9,
                NOW(), $10, $11,
                $12,
                NOW(), NOW()
              )
            `, [
              signalType,                                                    // signal_type (ENUM)
              companyHint || 'Unknown',                                      // company_name
              confidence,                                                    // confidence_score
              JSON.stringify({ signals, themes, geos, amount_millions: amount }), // scoring_breakdown
              `${item.title}`.substring(0, 1000),                            // evidence_summary
              item.description.substring(0, 500),                            // evidence_snippet
              [docId],                                                       // evidence_doc_ids UUID[]
              item.url,                                                      // source_url
              docId,                                                         // source_document_id (UUID FK)
              item.pubDate ? new Date(item.pubDate).toISOString() : null,    // signal_date
              signalType.match(/hiring|leadership/) ? 'talent' :
                signalType.match(/capital/) ? 'capital' :
                signalType.match(/ma_/) ? 'ma' : 'market',                  // signal_category
              hiringImpl ? JSON.stringify(hiringImpl) : null,                // hiring_implications
            ]);
            signalsCreated++;
          } catch (e) {
            // Enum mismatch or constraint violation — log once for debugging
            if (e.message.includes('invalid input value for enum')) {
              console.log(`     ⚠️ Enum mismatch: "${signalType}" not in signal_type enum`);
            }
          }
        }
      }
    } catch (err) { skipped++; }
  }

  // Update source stats
  try {
    await pool.query(
      `UPDATE rss_sources SET last_fetched_at = NOW(), consecutive_errors = 0, last_error = NULL WHERE id = $1`,
      [source.id]
    );
  } catch(e) {}

  console.log(`     ✅ ${success} new, ${skipped} skipped, ${signalsCreated} signals`);
  return { success, skipped, signals: signalsCreated };
}

async function harvest(slugFilter) {
  // Query uses actual rss_sources columns
  let query = `SELECT id, name, source_type, url FROM rss_sources WHERE enabled = true`;
  const params = [];
  if (slugFilter) { query += ` AND name ILIKE $1`; params.push(`%${slugFilter}%`); }
  query += ` ORDER BY name`;

  const { rows: sources } = await pool.query(query, params);
  console.log('═'.repeat(60));
  console.log('  📰 MITCHELLAKE NEWS & PR HARVESTER');
  console.log('═'.repeat(60));
  console.log(`  Sources: ${sources.length} active\n`);

  let totalNew = 0, totalSkipped = 0, totalSignals = 0;
  for (const src of sources) {
    try {
      const r = await harvestSource(src);
      totalNew += r.success; totalSkipped += r.skipped; totalSignals += r.signals;
    } catch (err) { console.log(`     ❌ ${err.message}`); }
    await sleep(DELAY_MS);
  }
  console.log('\n' + '═'.repeat(60));
  console.log(`  DONE: ${totalNew} new docs, ${totalSignals} signals, ${totalSkipped} skipped`);
  console.log('═'.repeat(60));
}

async function showStats() {
  console.log('═'.repeat(60));
  console.log('  📊 NEWS HARVESTER — STATS');
  console.log('═'.repeat(60));

  const docs = await pool.query(`SELECT COUNT(*) as total FROM external_documents`);
  console.log(`\n  Total documents: ${docs.rows[0].total}`);

  const newsDocs = await pool.query(`SELECT COUNT(*) as total FROM external_documents WHERE source_type = 'news_pr'`);
  console.log(`  News/PR documents: ${newsDocs.rows[0].total}`);

  const signals = await pool.query(`SELECT signal_type::text, COUNT(*) as cnt FROM signal_events GROUP BY signal_type ORDER BY cnt DESC`);
  if (signals.rows.length > 0) {
    console.log('\n  Signals by type:');
    signals.rows.forEach(r => console.log(`    ${String(r.cnt).padStart(5)} — ${r.signal_type}`));
  }

  const bySource = await pool.query(`
    SELECT rs.name, COUNT(ed.id) as docs, rs.last_fetched_at, rs.consecutive_errors
    FROM rss_sources rs
    LEFT JOIN external_documents ed ON rs.id = ed.source_id
    WHERE rs.enabled = true
    GROUP BY rs.id ORDER BY docs DESC
  `);
  if (bySource.rows.length > 0) {
    console.log('\n  Source                            | Docs  | Last Fetch        | Errors');
    console.log('  ' + '─'.repeat(72));
    for (const r of bySource.rows) {
      const nm = r.name.substring(0, 33).padEnd(33);
      const dt = r.last_fetched_at ? new Date(r.last_fetched_at).toISOString().substring(0, 16) : 'Never';
      console.log(`  ${nm}| ${String(r.docs).padStart(5)} | ${dt} | ${r.consecutive_errors || 0}`);
    }
  }

  console.log('═'.repeat(60));
}

// ══════════════════════════════════════════════════════════════
// MAIN
// ══════════════════════════════════════════════════════════════

async function main() {
  const args = process.argv.slice(2);
  try {
    if (args.includes('--seed')) await seedSources();
    else if (args.includes('--stats')) await showStats();
    else {
      const i = args.indexOf('--source');
      await harvest(i >= 0 ? args[i + 1] : null);
    }
  } finally { await pool.end(); }
}

main().catch(err => { console.error('Fatal:', err); pool.end(); process.exit(1); });
