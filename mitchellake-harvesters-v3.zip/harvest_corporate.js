#!/usr/bin/env node
/**
 * MitchelLake Signal Intelligence — Corporate Harvester v3
 * 
 * Enriches company profiles from public registries + filings:
 *   - SEC EDGAR (US public companies)
 *   - Companies House (UK)
 *   - ASIC / ABN Lookup (Australia) — future
 *   - ACRA (Singapore) — future
 * 
 * Matched to actual MLX schema:
 *   companies      → name, website, industry, metadata (jsonb), etc.
 *   signal_events   → signal_type ENUM, confidence_score, evidence_summary, etc.
 *   external_documents → source_type, source_url, source_url_hash, etc.
 * 
 * Usage:
 *   node scripts/harvest_corporate.js --company NVDA    # Enrich by ticker
 *   node scripts/harvest_corporate.js --company "Canva" # Enrich by name
 *   node scripts/harvest_corporate.js --sec-recent      # Recent SEC 8-K filings
 *   node scripts/harvest_corporate.js --uk "Revolut"    # UK Companies House
 *   node scripts/harvest_corporate.js --enrich-all      # Enrich all MLX companies
 *   node scripts/harvest_corporate.js --stats           # Statistics
 */

require('dotenv').config();
const { Pool } = require('pg');
const crypto = require('crypto');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

// SEC requires company email in User-Agent
const SEC_USER_AGENT = 'MitchelLakeSignals/1.0 (jt@mitchellake.com)';
const DELAY_MS = 300; // SEC rate limit: 10 req/sec
const DEBUG = process.argv.includes('--debug');

// ══════════════════════════════════════════════════════════════
// SIGNAL TYPE MAPPING → valid signal_type ENUM values
// ══════════════════════════════════════════════════════════════
//
// signal_type ENUM: capital_raising, geographic_expansion, strategic_hiring,
//   ma_activity, partnership, product_launch, leadership_change, layoffs, restructuring
//

const SEC_FILING_SIGNALS = {
  '8-K':  { type: 'leadership_change', category: 'corporate', confidence: 0.6 },
  '10-K': { type: null, category: 'financials', confidence: 0.3 },  // Annual — no signal unless parsed
  '10-Q': { type: null, category: 'financials', confidence: 0.2 },
  'S-1':  { type: 'capital_raising', category: 'capital', confidence: 0.9 },
  'S-3':  { type: 'capital_raising', category: 'capital', confidence: 0.7 },
  '13D':  { type: 'ma_activity', category: 'ma', confidence: 0.7 },
  '13G':  { type: 'capital_raising', category: 'capital', confidence: 0.5 },
  'SC 13D': { type: 'ma_activity', category: 'ma', confidence: 0.8 },
  'DEFA14A': { type: 'leadership_change', category: 'talent', confidence: 0.6 },
  'DEF 14A': { type: 'leadership_change', category: 'talent', confidence: 0.5 },
};

// 8-K item detection for more specific signals
const EIGHT_K_ITEMS = {
  '1.01': { signal: 'ma_activity', detail: 'Entry into Material Definitive Agreement' },
  '1.02': { signal: 'restructuring', detail: 'Termination of Material Definitive Agreement' },
  '2.01': { signal: 'ma_activity', detail: 'Completion of Acquisition/Disposition' },
  '2.05': { signal: 'restructuring', detail: 'Costs Associated with Exit/Disposal' },
  '2.06': { signal: 'restructuring', detail: 'Material Impairments' },
  '5.02': { signal: 'leadership_change', detail: 'Departure/Election of Directors or Officers' },
  '5.03': { signal: 'restructuring', detail: 'Amendments to Articles' },
  '7.01': { signal: null, detail: 'Regulation FD Disclosure' },
  '8.01': { signal: null, detail: 'Other Events' },
};

// ══════════════════════════════════════════════════════════════
// HELPERS
// ══════════════════════════════════════════════════════════════

const sleep = ms => new Promise(r => setTimeout(r, ms));
function md5(str) { return crypto.createHash('md5').update(str || '').digest('hex'); }

async function fetchJSON(url, userAgent) {
  const response = await fetch(url, {
    headers: { 'User-Agent': userAgent || SEC_USER_AGENT, 'Accept': 'application/json' },
    signal: AbortSignal.timeout(15000),
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json();
}

// ══════════════════════════════════════════════════════════════
// SEC EDGAR
// ══════════════════════════════════════════════════════════════

async function secSearchCompany(query) {
  // EDGAR company search API
  const url = `https://efts.sec.gov/LATEST/search-index?q=${encodeURIComponent(query)}&dateRange=custom&startdt=2024-01-01&forms=8-K,S-1,10-K`;
  try {
    const data = await fetchJSON(url);
    return data.hits?.hits || [];
  } catch (e) {
    // Fallback: company tickers API
    const tickerUrl = `https://efts.sec.gov/LATEST/search-index?q=%22${encodeURIComponent(query)}%22&forms=10-K`;
    try { return (await fetchJSON(tickerUrl)).hits?.hits || []; }
    catch (e2) { return []; }
  }
}

async function secGetCompanyByCIK(cik) {
  const paddedCIK = String(cik).padStart(10, '0');
  const url = `https://data.sec.gov/submissions/CIK${paddedCIK}.json`;
  return fetchJSON(url);
}

async function secGetRecentFilings(cik) {
  const company = await secGetCompanyByCIK(cik);
  const filings = company?.filings?.recent || {};
  const results = [];
  const forms = filings.form || [];
  const dates = filings.filingDate || [];
  const accessions = filings.accessionNumber || [];
  const descriptions = filings.primaryDocDescription || [];

  for (let i = 0; i < Math.min(forms.length, 20); i++) {
    results.push({
      form: forms[i],
      date: dates[i],
      accession: accessions[i],
      description: descriptions[i] || '',
      url: `https://www.sec.gov/Archives/edgar/data/${cik}/${accessions[i]?.replace(/-/g, '')}/`,
    });
  }
  return { company, filings: results };
}

async function enrichFromSEC(query) {
  console.log(`\n  🏛️  SEC EDGAR: Searching "${query}"...`);

  // Try as CIK first if numeric, else search
  let cik = null;
  if (/^\d+$/.test(query)) {
    cik = query;
  } else {
    // Try ticker lookup
    try {
      const tickers = await fetchJSON('https://www.sec.gov/files/company_tickers.json');
      const match = Object.values(tickers).find(t =>
        t.ticker?.toUpperCase() === query.toUpperCase() ||
        t.title?.toUpperCase().includes(query.toUpperCase())
      );
      if (match) {
        cik = match.cik_str;
        console.log(`     Found: ${match.title} (${match.ticker}) CIK: ${cik}`);
      }
    } catch (e) {
      console.log(`     ⚠️ Ticker lookup failed: ${e.message}`);
    }
    await sleep(DELAY_MS);
  }

  if (!cik) {
    console.log('     ❌ Company not found in SEC');
    return null;
  }

  const { company, filings } = await secGetRecentFilings(cik);
  console.log(`     📄 ${company.name} — ${filings.length} recent filings`);

  // Upsert company
  const companyData = {
    name: company.name,
    ticker: company.tickers?.[0],
    exchanges: company.exchanges,
    sic: company.sic,
    sic_description: company.sicDescription,
    state: company.stateOfIncorporation,
    fiscal_year_end: company.fiscalYearEnd,
    cik: cik,
    website: company.website || null,
    industry: company.sicDescription || null,
  };

  let companyId;
  try {
    const result = await pool.query(`
      INSERT INTO companies (name, website, industry, metadata, created_at, updated_at)
      VALUES ($1, $2, $3, $4, NOW(), NOW())
      ON CONFLICT (name) DO UPDATE SET
        website = COALESCE(EXCLUDED.website, companies.website),
        industry = COALESCE(EXCLUDED.industry, companies.industry),
        metadata = companies.metadata || EXCLUDED.metadata,
        updated_at = NOW()
      RETURNING id
    `, [
      companyData.name,
      companyData.website,
      companyData.industry,
      JSON.stringify(companyData),
    ]);
    companyId = result.rows[0].id;
    console.log(`     ✅ Company upserted: ${companyData.name} (${companyId})`);
  } catch (e) {
    console.log(`     ⚠️ Company upsert: ${e.message}`);
    // Try to find existing
    const existing = await pool.query(`SELECT id FROM companies WHERE name ILIKE $1 LIMIT 1`, [`%${companyData.name}%`]);
    companyId = existing.rows[0]?.id;
  }

  // Process filings → signal_events
  let signalsCreated = 0;
  for (const filing of filings) {
    const signalInfo = SEC_FILING_SIGNALS[filing.form];
    if (!signalInfo || !signalInfo.type) continue;

    const sourceUrlHash = md5(`sec|${cik}|${filing.accession}`);

    // Store filing as external_document
    let docId;
    try {
      const docResult = await pool.query(`
        INSERT INTO external_documents (
          source_type, source_name, source_url, source_url_hash,
          title, content, author,
          published_at, fetched_at, processing_status, created_at
        ) VALUES (
          'sec_filing', 'SEC EDGAR', $1, $2,
          $3, $4, $5,
          $6, NOW(), 'processed', NOW()
        )
        ON CONFLICT (source_url_hash) DO NOTHING
        RETURNING id
      `, [
        filing.url,
        sourceUrlHash,
        `${companyData.name} — ${filing.form} Filing`,
        filing.description || `${filing.form} filed ${filing.date}`,
        companyData.name,
        filing.date ? new Date(filing.date).toISOString() : null,
      ]);
      docId = docResult.rows[0]?.id;
    } catch (e) { /* dup */ }

    if (!docId) continue;

    // Create signal_event
    try {
      await pool.query(`
        INSERT INTO signal_events (
          signal_type, company_id, company_name,
          confidence_score, scoring_breakdown,
          evidence_summary, evidence_snippet, evidence_doc_ids,
          source_url, source_document_id,
          detected_at, signal_date, signal_category,
          hiring_implications,
          created_at, updated_at
        ) VALUES (
          $1::signal_type, $2, $3,
          $4, $5,
          $6, $7, $8,
          $9, $10,
          NOW(), $11, $12,
          $13,
          NOW(), NOW()
        )
      `, [
        signalInfo.type,
        companyId,
        companyData.name,
        signalInfo.confidence,
        JSON.stringify({ filing_type: filing.form, description: filing.description }),
        `${companyData.name} filed ${filing.form}: ${filing.description || 'SEC Filing'}`,
        (filing.description || `${filing.form} filing`).substring(0, 500),
        docId ? [docId] : null,
        filing.url,
        docId,
        filing.date ? new Date(filing.date).toISOString() : null,
        signalInfo.category,
        signalInfo.type === 'leadership_change'
          ? JSON.stringify([{ type: 'backfill', detail: 'SEC filing indicates leadership changes', urgency: 'medium' }])
          : signalInfo.type === 'capital_raising'
          ? JSON.stringify([{ type: 'team_build', detail: 'Capital raising typically leads to hiring', urgency: 'medium' }])
          : null,
      ]);
      signalsCreated++;
      if (DEBUG) console.log(`     📊 Signal: ${signalInfo.type} (${filing.form} — ${filing.date})`);
    } catch (e) {
      if (e.message.includes('invalid input value for enum')) {
        console.log(`     ⚠️ Enum mismatch: "${signalInfo.type}"`);
      } else if (DEBUG) {
        console.log(`     ⚠️ Signal: ${e.message.substring(0, 80)}`);
      }
    }
    await sleep(DELAY_MS);
  }

  console.log(`     📊 Created ${signalsCreated} signals from ${filings.length} filings`);
  return { company: companyData, filings: filings.length, signals: signalsCreated };
}

// ══════════════════════════════════════════════════════════════
// UK COMPANIES HOUSE
// ══════════════════════════════════════════════════════════════

async function enrichFromUK(query) {
  const apiKey = process.env.COMPANIES_HOUSE_API_KEY;
  if (!apiKey) {
    console.log('  ⚠️ COMPANIES_HOUSE_API_KEY not set — skipping UK enrichment');
    return null;
  }

  console.log(`\n  🇬🇧 Companies House: Searching "${query}"...`);

  const auth = Buffer.from(`${apiKey}:`).toString('base64');
  const searchUrl = `https://api.company-information.service.gov.uk/search/companies?q=${encodeURIComponent(query)}&items_per_page=5`;

  const response = await fetch(searchUrl, {
    headers: { 'Authorization': `Basic ${auth}` },
    signal: AbortSignal.timeout(10000),
  });
  if (!response.ok) throw new Error(`Companies House API: ${response.status}`);
  const data = await response.json();

  const items = data.items || [];
  if (items.length === 0) {
    console.log('     ❌ No results');
    return null;
  }

  const company = items[0];
  console.log(`     Found: ${company.title} (${company.company_number})`);

  // Get officers
  await sleep(500);
  const officerUrl = `https://api.company-information.service.gov.uk/company/${company.company_number}/officers?items_per_page=50`;
  let officers = [];
  try {
    const offResp = await fetch(officerUrl, { headers: { 'Authorization': `Basic ${auth}` }, signal: AbortSignal.timeout(10000) });
    if (offResp.ok) {
      const offData = await offResp.json();
      officers = (offData.items || []).filter(o => !o.resigned_on);
      console.log(`     👥 Active officers: ${officers.length}`);
    }
  } catch (e) { console.log(`     ⚠️ Officers: ${e.message}`); }

  // Upsert company
  try {
    await pool.query(`
      INSERT INTO companies (name, website, industry, metadata, created_at, updated_at)
      VALUES ($1, NULL, $2, $3, NOW(), NOW())
      ON CONFLICT (name) DO UPDATE SET
        metadata = companies.metadata || EXCLUDED.metadata,
        updated_at = NOW()
    `, [
      company.title,
      company.company_type || null,
      JSON.stringify({
        uk_company_number: company.company_number,
        company_status: company.company_status,
        company_type: company.company_type,
        date_of_creation: company.date_of_creation,
        registered_office_address: company.registered_office_address,
        officers: officers.map(o => ({
          name: o.name,
          role: o.officer_role,
          appointed_on: o.appointed_on,
        })),
      }),
    ]);
    console.log(`     ✅ Company upserted: ${company.title}`);
  } catch (e) { console.log(`     ⚠️ Upsert: ${e.message}`); }

  return { company: company.title, officers: officers.length };
}

// ══════════════════════════════════════════════════════════════
// ENRICH ALL MLX COMPANIES
// ══════════════════════════════════════════════════════════════

async function enrichAll() {
  console.log('═'.repeat(60));
  console.log('  🏢 ENRICH ALL MLX COMPANIES');
  console.log('═'.repeat(60));

  const { rows: companies } = await pool.query(`
    SELECT id, name, metadata FROM companies
    WHERE metadata IS NULL OR metadata->>'cik' IS NULL
    ORDER BY name LIMIT 50
  `);
  console.log(`\n  Companies to enrich: ${companies.length}\n`);

  let enriched = 0;
  for (const co of companies) {
    try {
      const result = await enrichFromSEC(co.name);
      if (result) enriched++;
    } catch (e) {
      console.log(`  ❌ ${co.name}: ${e.message}`);
    }
    await sleep(1000);
  }

  console.log(`\n  ✅ Enriched ${enriched}/${companies.length} companies`);
  console.log('═'.repeat(60));
}

// ══════════════════════════════════════════════════════════════
// STATS
// ══════════════════════════════════════════════════════════════

async function showStats() {
  console.log('═'.repeat(60));
  console.log('  📊 CORPORATE HARVESTER — STATS');
  console.log('═'.repeat(60));

  const companies = await pool.query(`SELECT COUNT(*) as c FROM companies`);
  console.log(`\n  Total companies: ${companies.rows[0].c}`);

  const enriched = await pool.query(`SELECT COUNT(*) as c FROM companies WHERE metadata IS NOT NULL AND metadata != '{}'::jsonb`);
  console.log(`  Enriched: ${enriched.rows[0].c}`);

  const secDocs = await pool.query(`SELECT COUNT(*) as c FROM external_documents WHERE source_type = 'sec_filing'`);
  console.log(`  SEC filings stored: ${secDocs.rows[0].c}`);

  const signals = await pool.query(`SELECT signal_type::text, COUNT(*) as cnt FROM signal_events GROUP BY signal_type ORDER BY cnt DESC`);
  if (signals.rows.length > 0) {
    console.log('\n  All signals by type:');
    signals.rows.forEach(r => console.log(`    ${String(r.cnt).padStart(5)} — ${r.signal_type}`));
  }

  console.log('═'.repeat(60));
}

// ══════════════════════════════════════════════════════════════
// MAIN
// ══════════════════════════════════════════════════════════════

async function main() {
  const args = process.argv.slice(2);
  try {
    if (args.includes('--stats')) await showStats();
    else if (args.includes('--enrich-all')) await enrichAll();
    else if (args.includes('--company')) {
      const i = args.indexOf('--company');
      const query = args[i + 1];
      if (!query) { console.error('Usage: --company <ticker_or_name>'); process.exit(1); }
      await enrichFromSEC(query);
    }
    else if (args.includes('--uk')) {
      const i = args.indexOf('--uk');
      const query = args[i + 1];
      if (!query) { console.error('Usage: --uk <company_name>'); process.exit(1); }
      await enrichFromUK(query);
    }
    else {
      console.log(`
  Usage:
    node scripts/harvest_corporate.js --company NVDA    # SEC enrichment by ticker
    node scripts/harvest_corporate.js --company "Canva" # SEC enrichment by name
    node scripts/harvest_corporate.js --uk "Revolut"    # UK Companies House
    node scripts/harvest_corporate.js --enrich-all      # All MLX companies
    node scripts/harvest_corporate.js --stats           # Statistics
    node scripts/harvest_corporate.js --debug           # Verbose output
      `);
    }
  } finally { await pool.end(); }
}

main().catch(err => { console.error('Fatal:', err); pool.end(); process.exit(1); });
