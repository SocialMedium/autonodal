#!/usr/bin/env node
/**
 * MitchelLake Signal Intelligence — Podcast Harvester v3
 * 
 * Architecture (matched to actual MLX schema):
 *   rss_sources        → Podcast feed sources (source_type='podcast')
 *   external_documents  → Episodes (source_type='podcast')
 *   person_signals      → Person mentions matched to MLX people DB
 * 
 * NOTE: person_content_sources + person_content require person_id,
 *       so we use rss_sources + external_documents for general feeds,
 *       then create person_signals when matching candidates.
 * 
 * Usage:
 *   node scripts/harvest_podcasts.js --seed              # Seed 33 podcast feeds
 *   node scripts/harvest_podcasts.js --poll              # Poll all podcast feeds
 *   node scripts/harvest_podcasts.js --poll --source X   # Poll one feed
 *   node scripts/harvest_podcasts.js --detect            # Match episodes → people
 *   node scripts/harvest_podcasts.js --stats             # Statistics
 */

require('dotenv').config();
const { Pool } = require('pg');
const crypto = require('crypto');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

const DELAY_MS = 1500;
const USER_AGENT = 'MitchelLakeSignals/1.0 (Executive Search Intelligence)';
const POLL_MAX = 20;

// ══════════════════════════════════════════════════════════════
// DISCOVER PERSON_SIGNALS SCHEMA AT RUNTIME
// ══════════════════════════════════════════════════════════════

let personSignalsCols = null;

async function discoverPersonSignalsSchema() {
  try {
    const { rows } = await pool.query(`
      SELECT column_name FROM information_schema.columns 
      WHERE table_name = 'person_signals' ORDER BY ordinal_position
    `);
    personSignalsCols = rows.map(r => r.column_name);
    console.log(`  ✅ person_signals columns: ${personSignalsCols.join(', ')}`);
  } catch (e) {
    console.log(`  ⚠️ Could not read person_signals schema: ${e.message}`);
    personSignalsCols = [];
  }
}

// ══════════════════════════════════════════════════════════════
// PODCAST SOURCES (33 feeds)
// ══════════════════════════════════════════════════════════════

const PODCAST_SOURCES = [
  // VC / Startups
  { name: 'Equity (TechCrunch)', url: 'https://feeds.megaphone.fm/equitypod', signal_types: ['capital_raising'] },
  { name: 'This Week in Startups', url: 'https://feeds.megaphone.fm/thisweekinstartups', signal_types: ['capital_raising', 'strategic_hiring'] },
  { name: 'BG2Pod', url: 'https://feeds.megaphone.fm/bg2pod', signal_types: ['capital_raising'] },
  { name: 'Invest Like the Best', url: 'https://feeds.megaphone.fm/investlikethebest', signal_types: ['capital_raising', 'leadership_change'] },
  { name: 'The Prof G Pod', url: 'https://feeds.megaphone.fm/profgpod', signal_types: ['leadership_change'] },
  { name: 'Odd Lots (Bloomberg)', url: 'https://feeds.megaphone.fm/oddlots', signal_types: ['capital_raising', 'restructuring'] },
  { name: 'The Logan Bartlett Show', url: 'https://feeds.simplecast.com/4MR_eDvL', signal_types: ['capital_raising'] },
  { name: 'How I Built This', url: 'https://feeds.npr.org/510313/podcast.xml', signal_types: ['leadership_change'] },
  { name: 'Capital Allocators', url: 'https://feeds.megaphone.fm/capitalallocators', signal_types: ['capital_raising'] },

  // Tech / AI
  { name: 'Techmeme Ride Home', url: 'https://feeds.megaphone.fm/techmeme-ridehome', signal_types: ['product_launch', 'strategic_hiring'] },
  { name: 'No Priors', url: 'https://feeds.transistor.fm/no-priors-ai-machine-learning-technology-and-the-future', signal_types: ['product_launch'] },
  { name: 'Eye on AI', url: 'https://feeds.megaphone.fm/eye-on-ai', signal_types: ['strategic_hiring'] },
  { name: 'Practical AI', url: 'https://changelog.com/practicalai/feed', signal_types: ['product_launch'] },

  // Fintech
  { name: 'Fintech Takes', url: 'https://feeds.transistor.fm/fintech-takes', signal_types: ['capital_raising', 'partnership'] },
  { name: 'Bankless', url: 'https://feeds.megaphone.fm/bankless', signal_types: ['capital_raising'] },

  // Healthcare / Biotech
  { name: 'The Long Run', url: 'https://feeds.megaphone.fm/the-long-run', signal_types: ['capital_raising', 'leadership_change'] },

  // Climate / Cleantech
  { name: 'My Climate Journey', url: 'https://feeds.megaphone.fm/mcjcollective', signal_types: ['capital_raising'] },
  { name: 'Catalyst (Shayle Kann)', url: 'https://feeds.megaphone.fm/catalyst-with-shayle-kann', signal_types: ['capital_raising', 'product_launch'] },

  // Cybersecurity
  { name: 'Risky Business', url: 'https://risky.biz/feeds/risky-business/', signal_types: ['strategic_hiring', 'ma_activity'] },

  // UK / Europe
  { name: 'Riding Unicorns', url: 'https://feeds.buzzsprout.com/1876220.rss', signal_types: ['capital_raising'] },
  { name: 'Sifted Podcast', url: 'https://feeds.acast.com/public/shows/sifted-podcast', signal_types: ['capital_raising', 'geographic_expansion'] },
  { name: 'EU Startups Podcast', url: 'https://feeds.buzzsprout.com/1928182.rss', signal_types: ['capital_raising'] },
  { name: 'Seedcamp Sessions', url: 'https://feeds.transistor.fm/seedcamp-podcast', signal_types: ['capital_raising'] },

  // ANZ
  { name: 'Wild Hearts (Blackbird)', url: 'https://feeds.megaphone.fm/wild-hearts', signal_types: ['capital_raising'] },
  { name: 'AirTree Podcast', url: 'https://feeds.transistor.fm/airtree-ventures', signal_types: ['capital_raising'] },
  { name: 'Startup Daily AU Pod', url: 'https://feeds.megaphone.fm/startup-daily', signal_types: ['capital_raising', 'strategic_hiring'] },
  { name: 'Cut Through Venture', url: 'https://feeds.buzzsprout.com/1835129.rss', signal_types: ['capital_raising'] },

  // Asia
  { name: 'BRAVE Southeast Asia Tech', url: 'https://feeds.buzzsprout.com/1127723.rss', signal_types: ['capital_raising', 'geographic_expansion'] },
  { name: 'Analyse Asia', url: 'https://feeds.simplecast.com/OHnXsEB_', signal_types: ['capital_raising'] },
  { name: 'Hard Truths by Vertex', url: 'https://feeds.buzzsprout.com/1955098.rss', signal_types: ['capital_raising'] },

  // Web3
  { name: 'Unchained (Laura Shin)', url: 'https://feeds.megaphone.fm/unchained', signal_types: ['capital_raising'] },
  { name: 'Empire (Blockworks)', url: 'https://feeds.megaphone.fm/empire', signal_types: ['capital_raising'] },
];

// ══════════════════════════════════════════════════════════════
// SIGNAL & THEME DETECTION
// ══════════════════════════════════════════════════════════════

const EPISODE_SIGNALS = {
  capital_raising: /\b(series [A-Z]|seed|funding|raised?\s*\$|IPO|unicorn|valuation|pre-money|round)\b/i,
  ma_activity: /\b(acqui|merger|exit|sold to|bought by|strategic buyer)\b/i,
  leadership_change: /\b(CEO|CTO|CFO|new hire|appoint|resign|founder|co-founder|stepping down)\b/i,
  geographic_expansion: /\b(new market|international|scaling|expanding|global|launch)\b/i,
  layoffs: /\b(layoff|restructur|downsize|cut.*staff)\b/i,
};

const THEMES = {
  ai: /\b(AI|artificial intelligence|LLM|GPT|machine learning|deep learning|generative)\b/i,
  fintech: /\b(fintech|payments|banking|DeFi|crypto|blockchain)\b/i,
  healthcare: /\b(health|biotech|pharma|clinical|FDA|medical)\b/i,
  cybersecurity: /\b(cyber|security|hacking|breach|zero trust)\b/i,
  cleantech: /\b(climate|renewable|solar|EV|carbon|hydrogen|energy transition)\b/i,
  semiconductor: /\b(chip|semiconductor|GPU|NVIDIA|AMD|silicon)\b/i,
};

const EXEC_PATTERN = /\b(CEO|CTO|CFO|COO|CRO|CPO|CMO|CISO|VP|SVP|EVP|president|founder|co-founder|managing director|partner|general partner)\b/i;

// ══════════════════════════════════════════════════════════════
// HELPERS
// ══════════════════════════════════════════════════════════════

const sleep = ms => new Promise(r => setTimeout(r, ms));
function md5(str) { return crypto.createHash('md5').update(str || '').digest('hex'); }

function stripHTML(str) {
  if (!str) return '';
  return str.replace(/<!\[CDATA\[(.*?)\]\]>/gs, '$1').replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#x27;/g, "'").replace(/&[a-z]+;/gi, ' ')
    .replace(/\s+/g, ' ').trim();
}

function parseDuration(str) {
  if (!str) return null;
  if (/^\d+$/.test(str)) return parseInt(str);
  const hms = str.match(/(\d+):(\d+):(\d+)/);
  if (hms) return parseInt(hms[1]) * 3600 + parseInt(hms[2]) * 60 + parseInt(hms[3]);
  const ms = str.match(/(\d+):(\d+)/);
  if (ms) return parseInt(ms[1]) * 60 + parseInt(ms[2]);
  return null;
}

// ══════════════════════════════════════════════════════════════
// RSS PARSING
// ══════════════════════════════════════════════════════════════

async function fetchAndParseRSS(url) {
  const { parseString } = require('xml2js');
  const response = await fetch(url, {
    headers: { 'User-Agent': USER_AGENT, 'Accept': 'application/rss+xml, application/xml, text/xml, */*' },
    signal: AbortSignal.timeout(30000),
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const xml = await response.text();

  return new Promise((resolve, reject) => {
    parseString(xml, { explicitArray: false, trim: true }, (err, result) => {
      if (err) return reject(err);
      const channel = result?.rss?.channel;
      if (channel) {
        const items = Array.isArray(channel.item) ? channel.item : channel.item ? [channel.item] : [];
        return resolve(items.map(item => {
          const itunes = item['itunes:duration'] || item.duration;
          return {
            title: stripHTML(typeof item.title === 'object' ? item.title._ || '' : item.title || ''),
            description: stripHTML(typeof item.description === 'object' ? item.description._ || '' : item.description || ''),
            url: typeof item.link === 'object' ? item.link._ || '' : item.link || '',
            guid: item.guid?._ || item.guid || item.link || '',
            pubDate: item.pubDate || item['dc:date'] || null,
            author: item['dc:creator'] || item.author || item['itunes:author'] || null,
            audioUrl: item.enclosure?.$?.url || null,
            duration: parseDuration(typeof itunes === 'object' ? itunes._ : itunes),
          };
        }));
      }
      // Atom
      const feed = result?.feed;
      if (feed) {
        const entries = Array.isArray(feed.entry) ? feed.entry : feed.entry ? [feed.entry] : [];
        return resolve(entries.map(e => ({
          title: stripHTML(typeof e.title === 'object' ? e.title._ || '' : e.title || ''),
          description: stripHTML(typeof e.summary === 'object' ? e.summary._ || '' : e.summary || ''),
          url: e.link?.$?.href || e.id || '',
          guid: e.id || '',
          pubDate: e.published || e.updated || null,
          author: e.author?.name || null,
          audioUrl: null,
          duration: null,
        })));
      }
      resolve([]);
    });
  });
}

// ══════════════════════════════════════════════════════════════
// SEED → rss_sources (source_type='podcast')
// ══════════════════════════════════════════════════════════════

async function seedSources() {
  console.log('\n🌱 Seeding podcast sources into rss_sources...\n');
  let added = 0;
  for (const src of PODCAST_SOURCES) {
    try {
      const result = await pool.query(`
        INSERT INTO rss_sources (name, source_type, url, poll_interval_minutes, enabled, credibility_score, signal_types, created_at)
        VALUES ($1, 'podcast', $2, 1440, true, 0.6, $3, NOW())
        ON CONFLICT (url) DO NOTHING
        RETURNING id
      `, [src.name, src.url, src.signal_types]);
      if (result.rowCount > 0) { console.log(`  ✅ ${src.name}`); added++; }
      else console.log(`  ⏭️  ${src.name} (exists)`);
    } catch (err) { console.log(`  ❌ ${src.name}: ${err.message}`); }
  }
  console.log(`\n📊 Added ${added} new podcast sources`);
}

// ══════════════════════════════════════════════════════════════
// POLL → external_documents (source_type='podcast')
// ══════════════════════════════════════════════════════════════

async function pollSource(source) {
  const label = source.name;
  process.stdout.write(`  🎙️  ${label}... `);

  let items;
  try { items = await fetchAndParseRSS(source.url); }
  catch (err) {
    console.log(`❌ ${err.message}`);
    try { await pool.query(`UPDATE rss_sources SET consecutive_errors = COALESCE(consecutive_errors, 0) + 1, last_error = $1 WHERE id = $2`, [err.message, source.id]); } catch(e) {}
    return 0;
  }

  items = items.slice(0, POLL_MAX);
  let saved = 0;

  for (const item of items) {
    if (!item.title) continue;
    const sourceUrlHash = md5(item.guid || item.url || item.title);
    const fullText = `${item.title} ${item.description}`;
    const signals = Object.entries(EPISODE_SIGNALS).filter(([, p]) => p.test(fullText)).map(([s]) => s);
    const themes = Object.entries(THEMES).filter(([, p]) => p.test(fullText)).map(([t]) => t);
    const hasExec = EXEC_PATTERN.test(fullText);

    try {
      const result = await pool.query(`
        INSERT INTO external_documents (
          source_type, source_name, source_url, source_url_hash,
          title, content, summary, author,
          published_at, fetched_at,
          extracted_entities, extracted_signals,
          processing_status, source_id, created_at
        ) VALUES (
          'podcast', $1, $2, $3,
          $4, $5, $6, $7,
          $8, NOW(),
          $9, $10,
          'processed', $11, NOW()
        )
        ON CONFLICT (source_url_hash) DO NOTHING
        RETURNING id
      `, [
        label,
        (item.url || '').substring(0, 2000),
        sourceUrlHash,
        item.title.substring(0, 500),
        item.description.substring(0, 5000),
        item.description.substring(0, 500),
        item.author,
        item.pubDate ? new Date(item.pubDate).toISOString() : null,
        JSON.stringify({ has_exec_mention: hasExec }),
        JSON.stringify({ signals, themes, audio_url: item.audioUrl, duration_seconds: item.duration }),
        source.id,
      ]);
      if (result.rowCount > 0) saved++;
    } catch (err) { /* dup */ }
  }

  // Update source
  try { await pool.query(`UPDATE rss_sources SET last_fetched_at = NOW(), consecutive_errors = 0, last_error = NULL WHERE id = $1`, [source.id]); } catch(e) {}

  console.log(`${saved}/${items.length} new`);
  return saved;
}

async function pollAll(sourceFilter) {
  let query = `SELECT id, name, url FROM rss_sources WHERE source_type = 'podcast' AND enabled = true`;
  const params = [];
  if (sourceFilter) { query += ` AND name ILIKE $1`; params.push(`%${sourceFilter}%`); }
  query += ` ORDER BY name`;

  const { rows: sources } = await pool.query(query, params);
  console.log('═'.repeat(60));
  console.log(`  🎙️  PODCAST POLL — ${sources.length} sources`);
  console.log('═'.repeat(60) + '\n');

  let totalSaved = 0;
  for (const src of sources) {
    totalSaved += await pollSource(src);
    await sleep(DELAY_MS);
  }
  console.log('\n' + '═'.repeat(60));
  console.log(`  DONE: ${totalSaved} new episodes saved`);
  console.log('═'.repeat(60));
}

// ══════════════════════════════════════════════════════════════
// PERSON DETECTION — match episodes to MLX people
// ══════════════════════════════════════════════════════════════

async function detectPeople() {
  console.log('═'.repeat(60));
  console.log('  👤 PERSON DETECTION — matching episodes to candidates');
  console.log('═'.repeat(60) + '\n');

  await discoverPersonSignalsSchema();

  // Build name index from people table
  const { rows: people } = await pool.query(`
    SELECT id, full_name, current_title, current_company_name
    FROM people WHERE full_name IS NOT NULL AND LENGTH(full_name) > 5
    ORDER BY full_name
  `);
  console.log(`  📋 Name index: ${people.length} candidates`);

  // Get recent podcast episodes not yet scanned
  const { rows: episodes } = await pool.query(`
    SELECT id, title, content, source_name, source_url, published_at
    FROM external_documents
    WHERE source_type = 'podcast'
    AND processing_status = 'processed'
    ORDER BY published_at DESC NULLS LAST
    LIMIT 500
  `);
  console.log(`  🎙️  Episodes to scan: ${episodes.length}\n`);

  let matches = 0;

  for (const ep of episodes) {
    const text = `${ep.title} ${ep.content || ''}`;

    for (const person of people) {
      if (!person.full_name || person.full_name.length < 6) continue;

      // Full name match (case-insensitive)
      if (text.toLowerCase().includes(person.full_name.toLowerCase())) {
        // Build insert based on discovered schema
        try {
          if (personSignalsCols.includes('description')) {
            // Schema has: person_id, signal_type, signal_source, title, description, detected_at, metadata, etc.
            await pool.query(`
              INSERT INTO person_signals (person_id, signal_type, signal_source, title, description, detected_at)
              VALUES ($1, 'podcast_appearance'::person_signal_type, 'podcast', $2, $3, COALESCE($4, NOW()))
            `, [
              person.id,
              `Mentioned in: ${ep.title}`.substring(0, 300),
              `${person.full_name} mentioned in ${ep.source_name || 'podcast'} episode: "${ep.title}"`.substring(0, 1000),
              ep.published_at,
            ]);
          } else {
            // Fallback — try minimal columns
            await pool.query(`
              INSERT INTO person_signals (person_id, signal_type, detected_at)
              VALUES ($1, 'podcast_appearance'::person_signal_type, COALESCE($2, NOW()))
            `, [person.id, ep.published_at]);
          }
          matches++;
          console.log(`  ✅ ${person.full_name} → "${ep.title.substring(0, 60)}..."`);
        } catch (e) {
          if (!e.message.includes('duplicate')) {
            console.log(`  ⚠️ ${person.full_name}: ${e.message.substring(0, 80)}`);
          }
        }
      }
    }
  }

  console.log(`\n  📊 Found ${matches} person mentions across ${episodes.length} episodes`);
  console.log('═'.repeat(60));
}

// ══════════════════════════════════════════════════════════════
// STATS
// ══════════════════════════════════════════════════════════════

async function showStats() {
  console.log('═'.repeat(60));
  console.log('  📊 PODCAST HARVESTER — STATS');
  console.log('═'.repeat(60));

  const sources = await pool.query(`SELECT COUNT(*) as c FROM rss_sources WHERE source_type = 'podcast'`);
  console.log(`\n  Podcast sources: ${sources.rows[0].c}`);

  const episodes = await pool.query(`SELECT COUNT(*) as c FROM external_documents WHERE source_type = 'podcast'`);
  console.log(`  Total episodes: ${episodes.rows[0].c}`);

  try {
    const mentions = await pool.query(`SELECT COUNT(*) as c FROM person_signals WHERE signal_type = 'podcast_appearance'`);
    console.log(`  Person mentions: ${mentions.rows[0].c}`);
  } catch(e) {}

  const bySource = await pool.query(`
    SELECT rs.name, COUNT(ed.id) as eps, rs.last_fetched_at
    FROM rss_sources rs
    LEFT JOIN external_documents ed ON rs.id = ed.source_id AND ed.source_type = 'podcast'
    WHERE rs.source_type = 'podcast'
    GROUP BY rs.id ORDER BY eps DESC LIMIT 20
  `);
  if (bySource.rows.length > 0) {
    console.log('\n  Episodes by source:');
    bySource.rows.forEach(r => {
      const dt = r.last_fetched_at ? new Date(r.last_fetched_at).toISOString().substring(0, 16) : 'Never';
      console.log(`    ${String(r.eps).padStart(4)} — ${r.name.substring(0, 40).padEnd(40)} (${dt})`);
    });
  }

  console.log('═'.repeat(60));
}

// ══════════════════════════════════════════════════════════════
// MAIN
// ══════════════════════════════════════════════════════════════

async function main() {
  const args = process.argv.slice(2);
  try {
    if (args.includes('--seed')) await seedSources();
    else if (args.includes('--detect')) await detectPeople();
    else if (args.includes('--stats')) await showStats();
    else if (args.includes('--poll')) {
      const si = args.indexOf('--source');
      await pollAll(si >= 0 ? args[si + 1] : null);
    }
    else {
      console.log(`
  Usage:
    node scripts/harvest_podcasts.js --seed              # Seed 33 feeds
    node scripts/harvest_podcasts.js --poll              # Poll all
    node scripts/harvest_podcasts.js --poll --source X   # Poll one
    node scripts/harvest_podcasts.js --detect            # Match to candidates
    node scripts/harvest_podcasts.js --stats             # Statistics
      `);
    }
  } finally { await pool.end(); }
}

main().catch(err => { console.error('Fatal:', err); pool.end(); process.exit(1); });
